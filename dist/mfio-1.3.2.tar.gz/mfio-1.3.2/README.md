## mmfio
Read and write multiple types of files


## type
- iolib  
    - txt,img,json,xml,yaml,excel
- scanlib  
    - scan object

- log
    - logger


## usage
python setup.py sdist bdist_wheel

twine upload dist/*